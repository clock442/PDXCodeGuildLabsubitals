from django.apps import AppConfig


class TodoappConfig(AppConfig):
    name = 'todoapp'
