from django.contrib import admin
from .models import ToDoItem

admin.site.register(ToDoItem)